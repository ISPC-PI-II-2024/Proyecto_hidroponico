// Wokwi Custom Chip - For docs and examples see:
// https://docs.wokwi.com/chips-api/getting-started
//
// SPDX-License-Identifier: MIT
// Copyright 2023 Author name

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {

  pin_t pin_ao;  //el pin A0
  pin_t pin_do;  //el pin D0
  pin_t pin_vcc;  //el VCC
  pin_t pin_gnd;   //el GND
  uint32_t gas_attr;  //variable para obtener el valor de gas
  uint32_t threshold_attr;  //variable para valor de threshold
  
} chip_state_t;

//llamada al metodo
static void chip_timer_event(void *user_data);

void chip_timer_event(void *user_data) {

  chip_state_t *chip = (chip_state_t*)user_data;

  //                         Lectura de Atributos:
  //attr_read_float(chip->gas_attr) lee el valor del gas en un rango de 0 a 100%.
  //Este valor se convierte a un rango de voltaje de 0 a 5V multiplicándolo por 5.0 / 100.
  float voltage = (attr_read_float(chip->gas_attr))*5.0/100;
  //Lo mismo se hace para el valor del umbral (threshold_attr).
  float threshold_v = (attr_read_float(chip->threshold_attr))*5.0/100;

  //                          Verificación de Alimentación:
  //pin_read(chip->pin_vcc) verifica si el pin VCC está alto.
  //pin_read(chip->pin_gnd) verifica si el pin GND está bajo.
  int x = pin_read(chip->pin_vcc);
  int y = pin_read(chip->pin_gnd);
  //Si el pin VCC está alto y el pin GND está bajo, significa que el sensor está alimentado correctamente.
  if (pin_read(chip->pin_vcc) && !pin_read(chip->pin_gnd))
  {
                          //Escritura del Voltaje en el Pin Analógico:
    //escribe el voltaje calculado en el pin analógico A0.
    pin_dac_write(chip->pin_ao, voltage);

    //                        Control de la Salida Digital:
    //Si el voltaje del gas es mayor que el umbral, el pin digital D0 se pone en alto (HIGH).
    //este mismo pin conectado a D0 esta conectado al led y se prende , caso contrario se apaga
    if(voltage>threshold_v)
      pin_write(chip->pin_do, HIGH);
   else
   //Si el voltaje del gas es menor o igual al umbral, el pin digital D0 se pone en bajo (LOW).
      pin_write(chip->pin_do, LOW);
  }
}


void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t)); //por defecto, Asigna memoria para el estado del chip

                         // inicializacion de pines y atributos
   chip->pin_ao = pin_init("A0", ANALOG);
   chip->gas_attr = attr_init("gasPercent", 10);    //id del primer control
   chip->threshold_attr = attr_init("threshold", 50);  //id del segundo control
   chip->pin_do = pin_init("D0", OUTPUT_LOW); 
   chip->pin_vcc = pin_init("VCC", INPUT_PULLDOWN);
   chip->pin_gnd = pin_init("GND", INPUT_PULLUP);

  //                      Configuración del Temporizador:
   const timer_config_t timer_config = {
    .callback = chip_timer_event,
    .user_data = chip,
   };
   timer_t timer_id = timer_init(&timer_config);
   timer_start(timer_id, 1000, true);

  //printf("MQ2 Gas Sensor\n");
}
